import './App.css';
import Navbar from "./components/Navbar";
import Articles from "./Pages/Articles/Articles";
import Footer from "./components/Footer";

function App() {
  return (
    <div>
      <Navbar/>
        <br/><br/><br/>
      <div id="pages" className="container">
          <Articles/>
      </div>
        <Footer/>
    </div>
  );
}

export default App;
