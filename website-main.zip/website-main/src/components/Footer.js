import React, {Component} from 'react';

class Footer extends Component {
	render() {
		return (
			<div className="footer">
				<footer>
					<div className="card text-white">

					</div>
				</footer>
			</div>
		);
	}
}

export default Footer;