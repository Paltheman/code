import React, {Component} from 'react';
import ArticleStyler from "./ArticleStyler";
import articles_data from "./articles_data";

class Articles extends Component {
	render() {
		return (
			<div>
				{articles_data.map((article, i) => {
					return (<ArticleStyler
						key={i}
						title={article.title}
						body={article.body}
						createdBy={article.createdBy}/>)
				})}
			</div>
		);
	}
}

export default Articles;