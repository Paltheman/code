const ArticleStyler = (props) => {
	return (
		<div>
			<div className="card text-white bg-primary mb-3">
				<div className="card-header">{props.title}</div>
				<div className="card-body">
					<p className="card-text">{props.body}</p>
				</div>
				<div className="card-footer">Created by: <span className="text-muted">{props.createdBy}</span></div>
			</div>
		</div>
	);
}

export default ArticleStyler;