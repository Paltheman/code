import ts from "rollup-plugin-ts";
import filesize from "rollup-plugin-filesize";
//import {terser} from "rollup-plugin-terser";

export default {
	input: "./src/index.ts",
	output: {
		file: "dist/tools/js/app.js",
		format: "iife"
	},
	plugins: [ts(), filesize()]
}