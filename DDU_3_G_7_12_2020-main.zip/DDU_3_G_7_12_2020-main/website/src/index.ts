import ViewInit from "./components/Views/ViewInit";
import {dom} from "./components/Global/Global";
import {htmlAttrTop} from "./components/Functions/Dom";

dom.addEventListener("DOMContentLoaded", () => {
	htmlAttrTop("athene_core_system", "ready");
	htmlAttrTop("athene_core_system_version", "6.2.4");
	ViewInit();
})