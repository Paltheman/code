const dom = document;
const con = console;
const win = window;

export {dom, con, win};