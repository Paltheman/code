import Navbar from "./Navbar/Navbar";
import {createElem} from "../Functions/Dom";
import RoutesController from "../Controllers/RoutesController";
import Footer from "./Footer/Footer";


const appView = document.getElementById("app");

const navbar = createElem("header");
navbar.innerHTML = Navbar;

const mainElem = createElem("main");
mainElem.setAttribute("id", "routerIngest");
mainElem.setAttribute("class", "container card bg-secondary");
const mainElemInit = createElem("div");
mainElemInit.setAttribute("id", "initMain");
mainElemInit.appendChild(mainElem);

const footerElem = createElem("footer");
footerElem.innerHTML = Footer;


export default () => {
	// @ts-ignore
	appView.appendChild(navbar);
	//@ts-ignore
	appView.appendChild(mainElemInit);
	//@ts-ignore
	appView.appendChild(footerElem);

	new RoutesController();
}