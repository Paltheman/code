const AboutPage = `
<h1>About page bitch</h1>
`;

export default AboutPage;