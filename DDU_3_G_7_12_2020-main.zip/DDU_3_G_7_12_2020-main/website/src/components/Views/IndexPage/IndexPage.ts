const IndexPage = `
<h1>Hello</h1>
`;

export default IndexPage