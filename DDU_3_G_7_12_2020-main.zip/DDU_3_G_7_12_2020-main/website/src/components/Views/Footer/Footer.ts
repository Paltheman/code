const Footer = `
<div class="card" id="footer">
	<div class="card-body text-center">
		<div class="container-flow">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
					<h1>hello</h1>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
					<h4>Kontakt Informatio</h4>
					<ul class="list-group">
						<a class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" style="border: none;">
							Tlf: 
						</a>
						<a class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" style="border: none;">
							Email:  
						</a>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
`;

export default Footer;