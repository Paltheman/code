

export default (name: string, data: any) => {

}