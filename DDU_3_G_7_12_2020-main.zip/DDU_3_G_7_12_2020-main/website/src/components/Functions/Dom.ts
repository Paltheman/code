import {dom} from "../Global/Global";

function createElem(type: string) {
	return dom.createElement(type);
}

function htmlAttrTop(name: string, attr: string) {
	// @ts-ignore
	dom.querySelector("#htmlTag_start").setAttribute(name, attr)
}

export {createElem, htmlAttrTop};