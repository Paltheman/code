import {dom, win} from "../Global/Global";
import IndexPage from "../Views/IndexPage/IndexPage";
import AboutPage from "../Views/AboutPage/AboutPage";
import {htmlAttrTop} from "../Functions/Dom";

class RoutesController {
	currentPath;
	currentView;
	mainTag = dom.getElementById("routerIngest");

	constructor() {
		this.initVersionControl();
		this.initView();
	}

	getLocation() {
		let temp = win.location.hash;
		temp = temp.replace("#", "");
		return temp;
	}

	initView() {
		this.currentPath = this.getLocation();
		this.currentView = getCorrectView(this.currentPath);
		this.insertView();

		win.addEventListener("hashchange", () => {
			this.currentPath = this.getLocation();
			this.currentView = getCorrectView(this.currentPath);
			this.insertView();
		})
	}

	insertView() {
		// @ts-ignore
		this.mainTag.innerHTML = this.currentView;
	}

	private initVersionControl() {
		htmlAttrTop("athene_routes_controller_version", "2.2.4");
		htmlAttrTop("athene_ingest_engine_version", "3.1.6")
	}
}

function getCorrectView(path: string) {
	let view;
	switch (path) {
		case "":
			view = IndexPage;
			break;
		case "index":
			view = IndexPage;
			break;
		case "about":
			view = AboutPage;
			break;
		default:
			view = IndexPage;
	}

	return view;
}

export default RoutesController;