# idle_crypto_investor
 IDC
