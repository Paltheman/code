<div class="card">
	<div class="card-body text-center">
		<slot />
	</div>
</div>
