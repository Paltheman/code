# typescriptGameEngine_AG-vsg
Typescript Game Engine Project til 2.V HTX Albertslund

# SETUP
### clone eller download hele repoet
### open git bash eller anden terminal (prefer bash like)
## sikre dig at nodejs er installeret ellers [download det](https://nodejs.org)
#### udfør disse commands i projekt mappen
##### npm i
##### npm run build

###### Projektet er færdiggjort og har taget meget lang tid at færdiggøre
###### Projekt start 18/2/2019 og slut 27/4/2020-28/4/2020

###### Powerpoint er til når kursuset omkring denne engine skal begynde og jeg vil forklare hvad forskellen er fra de normale programmeringssprog som de er vant til
