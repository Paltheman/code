namespace NT {

    export class PerspectiveCamera extends BaseCamera {

        public constructor( name: string, sceneGraph?: SceneGraph ) {
            super( name, sceneGraph );
        }
    }
}